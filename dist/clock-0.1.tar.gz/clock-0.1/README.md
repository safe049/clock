# clock
Python terminal clock to make adding clock for your project more easy

## Usage
* To use the clock,simply use these lines in your project:

```python
import clock

clock.get_time()
```
*This will display the current time in the terminal.*

## Installation
* To install the clock, simply run the following command in your terminal:
`python setup.py install`
We will upload to PyPI soon

## License
MIT License

## Requirements
* Python 3.x